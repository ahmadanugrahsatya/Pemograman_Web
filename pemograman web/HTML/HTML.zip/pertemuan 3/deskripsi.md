![deskripsi](aset/deskripsi.jpeg)

# Deskripsi gambar 

## HTML 
hubungan antara html dengan gambar rumah pertama, ialah sebuah pengibaratan html maksudnya html jika di ibaratkan seperti pondasi rumah, hal ini tentu nya berkaitan dengan html yang juga html itu berfungsi sebagai struktur website

## CSS 
hubungan antara css dengan gambar rumah kedua, ialah sebuah pengibaratan css maksudnya css jika di ibaratkan seperti pondasi rumah yang telah diberikan tembok, atap rumah, cerobong asap, jendela, pintu, dan juga sudah di cat, hal ini tentunya berkaitan dengan css yang juga css itu berfungsi sebagai penghias atau mempercantik website

## JAVASCRIPT
hubungan antara javascript dengan gambar rumah ketiga, ialah sebuah pengibaratan javascript maksudnya javascript jika di ibaratkan seperti rumah yang sudah jadi dengan segala interaksi yang ada di dalam rumah seperti penyalaan lampu dan pembakaran kayu bakar, hal ini berkaitan dengan javascript yang dimana javascript di gunakan untuk di website agar adanya interaksi antara web dengan user yang masuk ke dalam web seperti ketika kita login ke web dan password yang di masukkan salah maka akan terjadi eror dan akan ada pemberian informasi bahwa password yang dimasukkan salah.



