# Sturktur dasar
Sturktur dasar html merupakan sebuah struktur yang terdiri dari elemen-elemen dasar yang dimana elemen-elemen tersebut akan membentuk kerangka dokumen html,contoh nya seperti berikut

```html
<!DOCTYPE html>

    <html>

        <head>

            <title>ini adalah judul</title>

        </head>

        <body>

            <p>apapun yang terjadi maka itu terjadi</p>

        </body>

    </html>
```

- Tag `<DOCTYPE html>` memberitahu web bahwa dokumen HTML adalah versi 5
- Tag pembuka `<html>` menandai awal sebuah dokumen HTML sampai dengan tag penutup `</html>`
- Tag pembuka `<head>` berisi informasi tentang halaman HTML sampai dengan tag penutup `</head>` ,biasanya dalam tag head terdapat tag `<title>` untuk memberiakan informasi judul halaman HTML
- Apapun tag yang berada di antara tag pembuka `<body>` sampai dengan tag penutup `</body>` akan tampil di web browser.


![ssan|](aset/ss.png)

![ssan3](aset/ss3.png)
# Anatomi Elemen HTML

## Tag Pembuka dan Tag Penutup
Tag pembuka dan tag penutup merupakan dua bagian dari suatu elemen dalam HTML yang berfungsi sebagai penentu awal dan akhir dari elemen tersebut. Tag pembuka akan dimulai dengan nama elemen yang diapit oleh tanda kurung sudut atau tanda lebih kecil dan tanda lebih besar ("<" dan ">"). Tag penutup juga hampir sama dengan tag pembuka, akan tetapi tag penutup memiliki karakter garis miring tambahan ("/") sebelum nama elemennya. contoh ini, `<a>` adalah tag pembuka, dan `</a>` adalah tag penutup

## Atribut tag

Atribut tag bisanya akan merujuk ke sebuah informasi tambahan tentang elemen html tertentu. bisanya atribut tag akan di sertakan didalam tag pembuka dan akan memberikan nilai khusus kepada elemen tersebut. Atribut berfungsi dalam menentukan dana mengonfigurasi sifat-sifat elemen, seperti warna, tautan, atau ukuran. 

## Isi atau konten tag
Isi atau konten tag biasa akan merujuk pada sebauh informasi yang akan ditempatan di antara dua tag yaitu tag pembuka dan tag penutup. Artinya, isi atau konten dari sebuah tag merupakan sebuah data yang akan ditampilkan atau diolah oleh web browser ketikan halaman html di-render, dan juga isi atau konten tag bisa dapat berupa teks, gambar, hyperlink, atau elemen-elemen html lainnya tergantung pada jenis tag html



```html
<a href="titip.html">pergi ke halaman selanjutnya</a>
```
- tag pembuka `<a>` merupakan tag yang di gunakan untuk memasang link di html dan tag penutup `</a>` untuk menutup code nya 
- href merupakan nama atribut yang dimana atribut ini berfungsi untuk menentukan arah atau tujuan link yang di simpan
- "titip.html" merupakan nilai atributnya yang dimana link ini menuju ke file baru yang telah  saya buat yang artinya  "titip.html" adalah tujuan link yang saya simpan
- "pergi kehalaman selanjutnya"merupakan isi konten yang berarti "pergi ke halaman selanjutnya"akan muncul sebagai link yang telah saya tentukan
![ssan2](aset/ss2.png)

![ssan 4](aset/ss4.png)

# Tag dasar

## Heading
Merupakan Tag HTML yang digunakan untuk menunjukkan bagian penting pada halaman website dan memiliki enam tingkatan yang berurutan yaitu H1 hingga H6. Namun setiap tag memiliki fungsi yang berbeda contoh nya 
1. Tag `<h1>` itu seperti topik utama dari sebuah website. Tag `<h1>` merupakan tag yang akan memberi tahu ke google tentang konten halaman tersebut, apa yang ada di dalamnya.
2. Tag `<h2>` sampai `<h6>` sebagai sub-judul, maksudnya seperti ini coba Bayangkan halaman website sebagai sebuah buku. Ketika H1 adalah judul buku, maka H2 sering digunakan dalam _heading_/bab sedangkan H3-H6 sebagai sub-bab.Tidak disarankan untuk melompati tiap urutannya, misalnya saat H1 menjadi _heading_ utama, maka _sub-heading_ harus menggunakan Tag H2, tidak boleh langsung melewati ke H3 atau H4.



