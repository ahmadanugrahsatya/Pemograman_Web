# Percobaan II
## Kode CSS
```css
button{
                width: 150px;
                height: 50px;
                color: white;
                font-size: 20px;
                text-align: right;
            }
```

## Color
### Before
![](ss1.png)

### After
![](ss3.png)

> [!Penjelasan]




## Font-size

### Before
![](ss1.png)


### After
![](ss2.png)


## Text-align

### Before
![](ss1.png)

### After
![](ss4.png)